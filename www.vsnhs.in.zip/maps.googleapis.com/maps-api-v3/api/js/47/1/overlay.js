google.maps.__gjsload__('overlay', function(_) {
    var ms = function(a) {
            this.g = a
        },
        Kka = function() {},
        ns = function(a) {
            a.$m = a.$m || new Kka;
            return a.$m
        },
        Lka = function(a) {
            this.Ga = new _.Rh(function() {
                var b = a.$m;
                if (a.getPanes()) {
                    if (a.getProjection()) {
                        if (!b.dm && a.onAdd) a.onAdd();
                        b.dm = !0;
                        a.draw()
                    }
                } else {
                    if (b.dm)
                        if (a.onRemove) a.onRemove();
                        else a.remove();
                    b.dm = !1
                }
            }, 0)
        },
        Mka = function(a, b) {
            function c() {
                return _.Vh(e.Ga)
            }
            var d = ns(a),
                e = d.kl;
            e || (e = d.kl = new Lka(a));
            _.Xa(d.pa || [], _.L.removeListener);
            var f = d.Qa = d.Qa || new _.Nq,
                g = b.__gm;
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("center", g, "projectionCenterQ");
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            f = d.tq = d.tq || new ms(f);
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            a.bindTo("projection", f, "outProjection");
            a.bindTo("panes", g);
            d.pa = [_.L.addListener(a, "panes_changed", c), _.L.addListener(g, "zoom_changed", c), _.L.addListener(g, "offset_changed", c), _.L.addListener(b, "projection_changed", c), _.L.addListener(g, "projectioncenterq_changed", c)];
            c();
            b instanceof
            _.Ef && (_.O(b, "Ox"), _.cl("Ox", "-p", a))
        },
        Qka = function(a) {
            if (a) {
                var b = a.getMap();
                if (Nka(a) !== b && b && b instanceof _.Ef) {
                    var c = b.__gm;
                    c.overlayLayer ? a.__gmop = new Oka(b, a, c.overlayLayer) : c.h.then(function(d) {
                        d = d.cc;
                        var e = new os(b, d);
                        d.Za(e);
                        c.overlayLayer = e;
                        Pka(a);
                        Qka(a)
                    })
                }
            }
        },
        Pka = function(a) {
            if (a) {
                var b = a.__gmop;
                b && (a.__gmop = null, _.dl("Ox", "-p", b.g), b.g.unbindAll(), b.g.set("panes", null), b.g.set("projection", null), b.i.yf(b), b.h && (b.h = !1, b.g.onRemove ? b.g.onRemove() : b.g.remove()))
            }
        },
        Nka = function(a) {
            return (a =
                a.__gmop) ? a.map : null
        },
        Oka = function(a, b, c) {
            this.map = a;
            this.g = b;
            this.i = c;
            this.h = !1;
            _.O(this.map, "Ox");
            _.cl("Ox", "-p", this.g);
            c.Me(this)
        },
        Rka = function(a, b) {
            a.g.get("projection") != b && (a.g.bindTo("panes", a.map.__gm), a.g.set("projection", b))
        },
        os = function(a, b) {
            this.j = a;
            this.i = b;
            this.g = null;
            this.h = []
        };
    _.D(ms, _.M);
    ms.prototype.changed = function(a) {
        "outProjection" != a && (a = !!(this.get("offset") && this.get("projectionTopLeft") && this.get("projection") && _.Je(this.get("zoom"))), a == !this.get("outProjection") && this.set("outProjection", a ? this.g : null))
    };
    var ps = {};
    _.D(Lka, _.M);
    ps.Me = function(a) {
        if (a) {
            var b = a.getMap();
            (ns(a).$p || null) !== b && (b && Mka(a, b), ns(a).$p = b)
        }
    };
    ps.yf = function(a) {
        var b = ns(a),
            c = b.Qa;
        c && c.unbindAll();
        (c = b.tq) && c.unbindAll();
        a.unbindAll();
        a.set("panes", null);
        a.set("projection", null);
        b.pa && _.Xa(b.pa, _.L.removeListener);
        b.pa = null;
        b.kl && (b.kl.Ga.ud(), b.kl = null);
        _.dl("Ox", "-p", a);
        delete ns(a).$p
    };
    var qs = {};
    Oka.prototype.draw = function() {
        this.h || (this.h = !0, this.g.onAdd && this.g.onAdd());
        this.g.draw && this.g.draw()
    };
    os.prototype.dispose = function() {};
    os.prototype.Bc = function(a, b, c, d, e, f, g, h) {
        var k = this.g = this.g || new _.Qm(this.j, this.i, function() {});
        k.Bc(a, b, c, d, e, f, g, h);
        a = _.A(this.h);
        for (b = a.next(); !b.done; b = a.next()) b = b.value, Rka(b, k), b.draw()
    };
    os.prototype.Me = function(a) {
        this.h.push(a);
        this.g && Rka(a, this.g);
        this.i.refresh()
    };
    os.prototype.yf = function(a) {
        _.cb(this.h, a)
    };
    qs.Me = Qka;
    qs.yf = Pka;
    _.rf("overlay", {
        po: function(a) {
            if (a) {
                (0, ps.yf)(a);
                (0, qs.yf)(a);
                var b = a.getMap();
                b && (b instanceof _.Ef ? (0, qs.Me)(a) : (0, ps.Me)(a))
            }
        },
        preventMapHitsFrom: function(a) {
            _.vn(a, {
                onClick: function(b) {
                    return _.$m(b.event)
                },
                Wc: function(b) {
                    return _.Xm(b)
                },
                Wg: function(b) {
                    return _.Ym(b)
                },
                Kd: function(b) {
                    return _.Ym(b)
                },
                gd: function(b) {
                    return _.Zm(b)
                }
            }).Qh(!0)
        },
        preventMapHitsAndGesturesFrom: function(a) {
            a.addEventListener("click", _.vf);
            a.addEventListener("contextmenu", _.vf);
            a.addEventListener("dblclick", _.vf);
            a.addEventListener("mousedown",
                _.vf);
            a.addEventListener("mousemove", _.vf);
            a.addEventListener("MSPointerDown", _.vf);
            a.addEventListener("pointerdown", _.vf);
            a.addEventListener("touchstart", _.vf);
            a.addEventListener("wheel", _.vf)
        }
    });
});